package com.example.trackmytracks;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    //Textview
    TextView KMStand;
    TextView KMAnzeige;
    private String myText;


    //listView
    ListView lstItems;
    ArrayList<String> tracks;
    ArrayAdapter<String> adapter; //listview Adapter

    //locationManager
    LocationManager locationManager;
    Location geoLocation;
    boolean onTheWay = false;


    //Datetime
    //die jetzige Zeit
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd 'um' HH:mm");
    long timestamp1;
    long timestamp2;
    Calendar cal = new GregorianCalendar();

    //Permissions
    final static String[] PERMISSONS = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.MANAGE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
    final static int PERMISSIONS_ALL = 1;

    //Für Berechnung Wegstrecke
    ArrayList<Location> trackedLocations = new ArrayList<Location>();
    float currentDistanz;
    float route;
    int KmStand = 0;

    //Database
    SQLiteDatabase mydatabase;
    String notDeleted = "False";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mydatabase  = openOrCreateDatabase("TrackmyTracks",MODE_PRIVATE,null);

        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS Tracks(id INTEGER PRIMARY KEY AUTOINCREMENT, TrackArt VARCHAR,Adresse VARCHAR, Zeit VARCHAR, Kilometer INTEGER, Deleted VARCHAR);");
        /*
        //Insert Values into DB - testen
        mydatabase.execSQL("INSERT INTO TutorialsPoint VALUES('admin','admin');");
        mydatabase.execSQL("INSERT INTO TutorialsPoint VALUES('admin1','admin1');");
        mydatabase.execSQL("INSERT INTO TutorialsPoint VALUES('admin2','admin2');");
        mydatabase.execSQL("INSERT INTO TutorialsPoint VALUES('admin3','admin3');");
        */

        Cursor resultSet = mydatabase.rawQuery("Select * from Tracks",null);


        //Inhalt von DB prüfen
        resultSet.moveToFirst();
        while (resultSet.moveToNext()) {
            String trackArt = resultSet.getString(1);
            String adresse = resultSet.getString(2);
            String zeit = resultSet.getString(3);
            String kilometer = resultSet.getString(4);
            Toast.makeText(this, "" + trackArt + " | " + adresse + " | " + zeit + " | " + kilometer, Toast.LENGTH_SHORT).show();
        }/*
        tracks.add(username + "" + password);
        */

        resultSet = mydatabase.rawQuery("Select Kilometer, id from Tracks ORDER BY id DESC LIMIT 1",null);
        resultSet.moveToFirst();

        //Textview
        KMStand = (TextView)findViewById(R.id.KMStand);
        KMAnzeige = (TextView)findViewById(R.id.KMAnzeige);
        if(resultSet.getCount() > 0)
            KMAnzeige.setText(resultSet.getString(0));

        //Listview
        lstItems = (ListView) findViewById(R.id.listView);
        tracks = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, tracks);
        lstItems.setAdapter(adapter);


        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(PERMISSONS, PERMISSIONS_ALL);
        }

        //Handler, damit alle 10 Sekunden ein Standort getrackt wird
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (onTheWay == true)
                getLocation();
                handler.postDelayed(this, 10000);
            }
        }, 1000);

        //Feld für KMAnzeige
        KMAnzeige.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mydialog = new AlertDialog.Builder(MainActivity.this);
                mydialog.setTitle("Kilometerstand anpassen");

                final EditText newKilometer = new EditText(MainActivity.this);
                newKilometer.setInputType(InputType.TYPE_CLASS_NUMBER);
                mydialog.setView(newKilometer);

                mydialog.setPositiveButton("Change", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        myText=newKilometer.getText().toString();
                        KmStand = Integer.parseInt(myText);
                        KMAnzeige.setText(myText);
                    }
                });

                mydialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                mydialog.show();
            }
        });



        final View.OnClickListener mListener = new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.button0:
                        getLocation();
                        onTheWay = true;
                        adapter.notifyDataSetChanged();
                        break;
                    case R.id.button1:
                        location("Arbeitsbeginn");
                        adapter.notifyDataSetChanged();
                        break;
                    case R.id.button3:
                        location("Ankunft");
                        adapter.notifyDataSetChanged();
                        break;
                    case R.id.button4:
                        location("Arbeitsende");
                        adapter.notifyDataSetChanged();
                        break;
                }
            }
        };
        findViewById(R.id.button0).setOnClickListener(mListener);
        findViewById(R.id.button1).setOnClickListener(mListener);
        findViewById(R.id.button3).setOnClickListener(mListener);
        findViewById(R.id.button4).setOnClickListener(mListener);


        //delete item from listview, eventuell mit longclick?
        lstItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final int which_item = position;

                new AlertDialog.Builder(MainActivity.this)
                        .setIcon(android.R.drawable.ic_delete)
                        .setTitle("Are you sure?")
                        .setMessage("Do you want to delete this position?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                tracks.remove(which_item);
                                mydatabase.execSQL("INSERT INTO Tracks (Deleted) VALUES('True')");
                                adapter.notifyDataSetChanged();

                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });
        lstItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view,
                                           int position, long arg3) {
                final int which_item = position;
                tracks.remove(which_item);
                adapter.notifyDataSetChanged();

                return false;
            }

        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete:
                new AlertDialog.Builder(MainActivity.this)
                        .setIcon(android.R.drawable.ic_delete)
                        .setTitle("Are you sure?")
                        .setMessage("Do you want to delete the database?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mydatabase.execSQL("DROP TABLE IF EXISTS Tracks");
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
                mydatabase.execSQL("CREATE TABLE IF NOT EXISTS Tracks(id INTEGER PRIMARY KEY AUTOINCREMENT, TrackArt VARCHAR,Adresse VARCHAR, Zeit VARCHAR, Kilometer INTEGER, Deleted VARCHAR);");

                return true;

            case R.id.export:
                File file = new File(getExternalFilesDir("MyFileDir"), "MyTracks.csv" );
                try {
                    file.createNewFile();
                    CSVWriter csvWrite = new CSVWriter(new FileWriter(file));
                    Cursor curCSV = mydatabase.rawQuery("SELECT * FROM  Tracks", null);
                    csvWrite.writeNext(curCSV.getColumnNames());
                    while (curCSV.moveToNext()) {
                        //Which column you want to exprort
                        String arrStr[] = new String[curCSV.getColumnCount()];
                        for (int i = 0; i < curCSV.getColumnCount() - 1; i++)
                            arrStr[i] = curCSV.getString(i);
                        csvWrite.writeNext(arrStr);
                    }
                    csvWrite.close();
                    curCSV.close();
                    Toast.makeText(this, "Exported", Toast.LENGTH_SHORT);
                } catch (Exception sqlEx) {
                    Log.e("MainActivity", sqlEx.getMessage(), sqlEx);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }




    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onLocationChanged(Location location) {
        trackedLocations.add(location);
        locationManager.removeUpdates(this);
        if (trackedLocations.size() == 1) {
            try {
                Geocoder geocoder = new Geocoder(MainActivity.this);
                List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                Address address = addresses.get(0);
                String street = address.getThoroughfare();
                String number = address.getSubThoroughfare();
                String zipCode = address.getPostalCode();
                String city = address.getLocality();
                timestamp1 = Instant.now().getEpochSecond();
                cal.setTime(new Date(timestamp1));
                Date currentTime1 = Calendar.getInstance().getTime();
                String Abfahrt = (street + " " + number + " " + zipCode + " " + city );
                String zeit = dateFormat.format(currentTime1);
                System.out.println("Test");
                try {
                    mydatabase.execSQL("INSERT INTO Tracks (TrackArt, Adresse, Zeit, Kilometer) VALUES('Abfahrt', '" + Abfahrt + "', '" + zeit + "', '" + KmStand + "')");
                }
                catch (SQLException e){
                    System.out.println(e);
                }
                tracks.add("Abfahrt: " + Abfahrt);
                adapter.notifyDataSetChanged();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    //Funktion für Buttons
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void location(String trackArt) {
        LocationManager lm1 = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location1 = lm1.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        double longitude1 = location1.getLongitude();
        double latitude1 = location1.getLatitude();
        try {
            Geocoder geocoder = new Geocoder(MainActivity.this);
            List<Address> addresses = geocoder.getFromLocation(latitude1, longitude1, 1);
            Address address = addresses.get(0);
            String street = address.getThoroughfare();
            String number = address.getSubThoroughfare();
            String zipCode = address.getPostalCode();
            String city = address.getLocality();
            Date currentTime2 = Calendar.getInstance().getTime();
            String Ankunft = (street + " " + number + " " + zipCode + " " + city);
            String zeit = dateFormat.format(currentTime2);

            switch (trackArt) {
                case "Ankunft":
                    berechneStrecke();
                    trackedLocations.removeAll(trackedLocations);
                    mydatabase.execSQL("INSERT INTO Tracks (TrackArt, Adresse, Zeit, Kilometer, Deleted) VALUES('" + trackArt + "', '" + Ankunft + "', '" + zeit + "', '" + KmStand + "', '" + notDeleted + "' )");
                    tracks.add(trackArt + ": " + street + " " + number + ", " + zipCode + " " + city);
                    onTheWay = false;
                    break;
                case "Arbeitsbeginn":
                    timestamp1 = Instant.now().getEpochSecond();
                    cal.setTime(new Date(timestamp1));
                    tracks.add(trackArt + ": " + dateFormat.format(currentTime2));
                    mydatabase.execSQL("INSERT INTO Tracks (TrackArt, Adresse, Zeit, Kilometer, Deleted) VALUES('" + trackArt + "', '" + Ankunft + "', '" + zeit + "', '" + KmStand + "','" + notDeleted + "')");
                    break;
                case "Arbeitsende":
                    timestamp2 = Instant.now().getEpochSecond();
                    long diff = timestamp2 - timestamp1;
                    long stunden = diff / 3600;             //seconds
                    long minuten = (diff % 3600) / 60;      //minuten
                    cal.setTime(new Date(timestamp2));
                    tracks.add(trackArt + ": " + dateFormat.format(currentTime2));
                    tracks.add("Arbeitszeit: " + stunden + " Stunde(n) " + minuten + " Minute(n)");
                    mydatabase.execSQL("INSERT INTO Tracks (TrackArt, Adresse, Zeit, Kilometer, Deleted) VALUES('" + trackArt + "', '" + Ankunft + "', '" + zeit + "', '" + KmStand + "'+,'" + notDeleted + "')");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Get current location
    @SuppressLint("MissingPermission")
    private void getLocation() {
        if (locationManager == null)
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 5, MainActivity.this);
            }
        }
    }

    //Berechnung Wegstrecke
    public void berechneStrecke(){
        currentDistanz = 0;

        if(trackedLocations.size()>1)
        {
            for(int i=1; i<trackedLocations.size(); i++) {
                currentDistanz += ((trackedLocations.get(i-1).distanceTo(trackedLocations.get(i))) / 1000);
            }
        }
        route = (float)(((int)(currentDistanz*100))/100.0);
        KmStand += route;
        String way = Float.toString(route);
        tracks.add("Gefahrene Kilometer: " + way);

    }
}