package com.example.trackmytracks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Testbutton6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testbutton6);
    }
}